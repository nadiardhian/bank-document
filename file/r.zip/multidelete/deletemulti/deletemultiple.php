<?php
$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db("multiedit", $con);

$edittable=$_POST['selector'];
$N = count($edittable);
for($i=0; $i < $N; $i++)
{
	$result = mysql_query("DELETE FROM files where id='$edittable[$i]'");
}
header("location: index.php");
mysql_close($con);
?>