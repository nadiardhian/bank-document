-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 18, 2012 at 05:52 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `multiedit`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `filename`, `email`, `address`) VALUES
(1, ' Jhon Smith', 'jhon@yahoo.com', 'bbububu uhuhuuh derwwd wdwdwd'),
(2, 'Bill Gates', 'bill@microsoft.com', 'edwew wewewewe ewewew fefefefefe feefefef efefefef'),
(3, 'Steve Jobs', 'steve@apple.com', 'vft ftftvftftf tvftfvtfbtftf ftbftfbtftft tfbtftftbftf ftbftftftfbtf tbfbtbftft'),
(4, 'Argie Policarpio', 'policarpio.argie@yahoo.com', 'brgy. zone 15, talisay city, negros occidental'),
(5, 'jhbjhh jhjhjh', 'jhjh@assa.com', 'jhjh hyu hjh jhj hjhjhjhj   hjhjhjh jhjhj'),
(6, 'qwerty asdfgh', 'qwerty.asdfgh@yahoo.com', 'keyboard acer loptop'),
(7, 'Jhon Purontong', 'porontong@yahoo.com', 'pasig City '),
(8, 'jhjhjhj', 'jjhjhjh', 'jgbvyrfjbuiuytryrtrbvtyy'),
(9, 'hjuyhuyu', 'uynyuynuy', 'uynuynuyuy'),
(10, 'hujhjhjhj', 'hjhjhjhjh', 'jhjhhjhhjhjhjhj');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
